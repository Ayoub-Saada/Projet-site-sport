<h1>Formulaire d'inscription</h1>
<form action="verif_user.php" method="post"></form>
<div>
    <label for="email">Email</label>
    <input type="email" name="email" id="email" class="form-control" placeholder="kean@dupond.fr" required>
</div>