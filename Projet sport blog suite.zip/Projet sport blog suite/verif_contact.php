<?php 

/* var_dump($_POST); 

$conn = mysqli_connect("localhost", "root", "", "contact");

$sql = "SELECT * FROM `user`;

$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)){
    var_dump($row);
} */


$nom = $_POST["nom"];
$prenom = $_POST["prenom"];     // toujours declarer les variables en premier
$email = $_POST["email"];
$telephone = $_POST["telephone"];
$sujet = $_POST["sujet"];
$message = $_POST["message"];

// Me connecter à ma base de donnée
$link = mysqli_connect("localhost", "root", "", "user", 3306);

// JE VERIFIE LA CONNEXION a ma BDD = BASE DE DONNEE
if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}

// MA REQUETE SQL
$sql = "SELECT * FROM user (nom, prenom, email, telephone, sujet, message) VALUES ('$nom', '$prenom', '$email' '$telephone','$sujet','$message')";

// verifier si il y a des champs saisie
if (!empty($nom) && !empty($prenom) && !empty($email) && !empty($telephone) && !empty($sujet) && !empty($message)) {
    if (mysqli_query($link, $sql)) {                         // TESTER SI MA REQUETE EST EXECUTE
        header("location:contact.php?add=1");
    }
} 
else {
    header("location:contact.php?add=0");
}
?>