<?php
// PDO (object = class);
// comment je peux instancier pdo j'appel ma class ou mon objet pdo

// JE DECLARE UNE VARIABLE ET JE STOCK MON $_POST; 
// AFFICHER LA VALEUR DE LID
/*  J'ai l'attribut NAME qui se trouve dans l'élément input de mon formulaire exemple <input type="text" name="nom"> */

// TU STOCK LA VALEUR DE CHAQUE DANS UNE VARIABLE
$nom = $_POST["nom"];
$prenom = $_POST["prenom"];
$email = $_POST["email"];
$telephone = $_POST["telephone"];
$sujet = $_POST["sujet"];
$message = $_POST["message"];

$host = "localhost";
$dbname = "user";
$dbuser = "root";
$dbpassword = "";

// essayer ma connection
try {
// J'ai intancié ma classe PDO pour me connecter à ma base de donnée
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $dbuser, $dbpassword);
// Je demande à attribuer un mode d'erreur qui est PDOEXCEPTION
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "Co reussis";
// VAR_DUMP ça va afficher une variable dans les détails (debuger)
}
// attraper une erreur
catch (PDOException $erreur) {
// -> permet de parcourir un objet (une classe) pour récuperer
// une fonction (methode) ou propriéter ($variable déclarer)
// get (affiche moi);
// set (modifie moi, insère, rajoute moi)
die($erreur->getMessage());
}
$sql = "INSERT INTO user contact sport (nom, prenom, email, telephone, sujet, message) VALUES (:nom, :prenom, :email, :telephone, :sujet, :message)";
// prepare ma requete($sql);
$prepare = $pdo->prepare($sql);
// j'execute ma requete (boolean); 
$exec = $prepare->execute([":nom" => $nom, ":prenom" => $prenom, ":email" => $email]);
// je test l'execution et je renvoi ok
// si la requete que j'execute est vrai alors sa marche
if($exec){
    echo "Insertion réussis <br>";
}else{
    echo "ERREUR d'insertion <br>";
}