<?php 

/* 
lexercice sur ORDER BY
$link = mysqli_connect("localhost", "root", "", "user");
$sql = "SELECT * FROM user ORDER BY nom DESC" ;                 
$query = mysqli_query($link,$sql); */

$link = mysqli_connect("localhost", "root", "", "user");
$sql = "SELECT CONCAT(prenom, ' ', nom , ' ' , email, ' ', message) AS identite, id, prenom, nom, email, message FROM user" ; 
$query = mysqli_query($link,$sql);

?>

<table class="table">
  <thead>
    <tr>

      <th scope="col">identite</th>
      <th scope="col">id</th>
      <th scope="col">prenom</th>
      <th scope="col">nom</th>
      <th scope="col">email</th>
      <th scope="col">message</th>
      
    </tr>
  </thead>

<?php while ($row = mysqli_fetch_assoc($query)): ?>

 <tbody>
    <tr>
      <th scope="row"><?php echo $row["identite"]?></th>
      <th scope="row"><a href="./user.php?id=".$id."><?php echo $row["id"]?></a></th>
      <th scope="row"><?php echo $row["prenom"]?></th>
      <th scope="row"><?php echo $row["nom"]?></th>
      <th scope="row"><?php echo $row["email"]?></th>
      <th scope="row"><?php echo $row["message"]?></th>

    </tr>
</tbody>

<?php endwhile; ?>
</table>

