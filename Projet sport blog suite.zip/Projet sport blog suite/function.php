<!-- //Function pour le menu (class items, links et titles ...) qui nous permet d'afficher le menu html en php -->

<!-- // Déclarer la fonction add_items

// Paramètre 1 array $class_item
// Paramètre 2 array $class_link        Ici les paramètres tableaux "array"
// Paramètre 3 array $link_url
// Paramètre 4 array $title -->

<?php
function $add_item(string $class_item, string $class_link, string $link_url, string $title){
    return <<<HTML
    <li class="$class_item">
        <a class="$class_link text-white" href="$url_link">$title</a>
    </li>
    HTML;
}
?>

<!-- __________

// Paramètre 1 string $class_item 
// Paramètre 2 string $class_link        Ici les chaînes de caractères tableaux "string"
// Paramètre 3 string $link_url
// Paramètre 4 string $title --> -->

<?php

function $add_item(string $class_item, string $class_link, string $link_url, string $title){
    return <<<HTML
    <li class="$class_item">
        <a class="$class_link text-white" href="$url_link">$title</a>
    </li>
    HTML;
}

?>