<?php

$id = $_GET["id"];
$link = mysqli_connect("localhost","root","","user");
$sql = "SELECT id, nom, prenom, email FROM `user` WHERE id = $id";
$query = mysqli_query($link,$sql);
$row = mysqli_fetch_assoc($query);

?>

<table class="table">
  <thead>
    <tr>

      <th scope="col">identite</th>
      <th scope="col">id</th>
      <th scope="col">prenom</th>
      <th scope="col">nom</th>
      <th scope="col">email</th>
      <th scope="col">message</th>
      
    </tr>
  </thead>

<?php while ($row = mysqli_fetch_assoc($query)): ?>

 <tbody>
    <tr>
      <th scope="row"><?php echo $row["identite"]?></th>
      <th scope="row"><?php echo $row["prenom"]?></th>
      <th scope="row"><?php echo $row["nom"]?></th>
      <th scope="row"><?php echo $row["email"]?></th>
      <th scope="row"><?php echo $row["message"]?></th>

    </tr>
</tbody>

<?php endwhile; ?>
</table>